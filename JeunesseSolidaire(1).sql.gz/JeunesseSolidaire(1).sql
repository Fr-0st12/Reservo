-- Adminer 4.8.1 MySQL 5.5.5-10.6.12-MariaDB-0ubuntu0.22.04.1 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP DATABASE IF EXISTS `JeunesseSolidaire`;
CREATE DATABASE `JeunesseSolidaire` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `JeunesseSolidaire`;

DROP TABLE IF EXISTS `equipements`;
CREATE TABLE `equipements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `prix` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

TRUNCATE `equipements`;
INSERT INTO `equipements` (`id`, `nom`, `image`, `prix`) VALUES
(1,	'Table',	'https://www.gosto.com/12118-home_default/table-modulaire-rectangulaire-l160xp80cm.jpg',	10),
(2,	'Chaise',	'https://www.axess-industries.com/mobilier-pour-les-etablissements-secondaires/chaise-scolaire-avec-4-pieds-tube-best-seller-p-400016-450x450.png',	5),
(3,	'Haut-parleur',	'https://m.media-amazon.com/images/I/717fcOPpXhL.jpg',	10),
(4,	'Microphone',	'https://www.wowevent.fr/wp-content/uploads/2018/03/Micro-1-1030x1030.jpg',	5),
(5,	'Chapiteau (3x3)',	'https://www.semio.fr/69102-large_default/chapiteau-de-reception-pyramide.jpg',	50),
(6,	'Chapiteau (4x4)',	'https://www.semio.fr/69102-large_default/chapiteau-de-reception-pyramide.jpg',	100),
(7,	'Chapiteau (6x6)',	'https://www.semio.fr/69102-large_default/chapiteau-de-reception-pyramide.jpg',	150);

DROP TABLE IF EXISTS `reservations`;
CREATE TABLE `reservations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `date_d` datetime DEFAULT NULL,
  `date_f` datetime DEFAULT '0000-00-00 00:00:00',
  `préau` int(11) DEFAULT NULL,
  `terrain` int(11) DEFAULT NULL,
  `salle_15` int(11) DEFAULT NULL,
  `cc1` int(11) DEFAULT NULL,
  `cc2` int(11) DEFAULT NULL,
  `chaises` int(11) DEFAULT NULL,
  `tables` int(11) DEFAULT NULL,
  `haut_parleurs` int(11) DEFAULT NULL,
  `micro` int(11) DEFAULT NULL,
  `chapiteau_3x3` int(11) DEFAULT NULL,
  `chapiteau_3x4` int(11) DEFAULT NULL,
  `chapiteau_3x6` int(11) DEFAULT NULL,
  `setup` int(11) DEFAULT NULL,
  `cleaning` int(11) DEFAULT NULL,
  `prix_total` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

TRUNCATE `reservations`;
INSERT INTO `reservations` (`id`, `id_user`, `date_d`, `date_f`, `préau`, `terrain`, `salle_15`, `cc1`, `cc2`, `chaises`, `tables`, `haut_parleurs`, `micro`, `chapiteau_3x3`, `chapiteau_3x4`, `chapiteau_3x6`, `setup`, `cleaning`, `prix_total`) VALUES
(1,	NULL,	'2024-04-13 00:00:00',	'2024-04-23 00:00:00',	1,	0,	1,	0,	1,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL),
(2,	NULL,	'2024-04-01 00:00:00',	'2024-04-02 00:00:00',	1,	1,	0,	0,	1,	2,	2,	72,	2,	2,	0,	2,	NULL,	NULL,	NULL),
(3,	NULL,	'2024-04-01 00:00:00',	'2024-04-01 00:00:00',	1,	1,	1,	0,	1,	53,	24,	0,	20,	20,	7,	0,	0,	0,	NULL),
(4,	NULL,	NULL,	'0000-00-00 00:00:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	0,	0,	NULL),
(5,	NULL,	NULL,	'0000-00-00 00:00:00',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	1,	0,	NULL),
(6,	NULL,	'2024-04-01 00:00:00',	'2024-04-01 00:00:00',	1,	1,	0,	1,	0,	0,	0,	0,	0,	0,	0,	0,	1,	0,	NULL);

DROP TABLE IF EXISTS `salles`;
CREATE TABLE `salles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `prix` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

TRUNCATE `salles`;
INSERT INTO `salles` (`id`, `nom`, `image`, `prix`) VALUES
(1,	'Préau',	'https://www.akena.com/sites/default/files/styles/phablet/public/2023-04/akena-produit-preau-2021-saint-urbain-019.jpg?itok=VY-9k7lc',	5000),
(2,	'Terrain',	'https://www.insep.fr/sites/default/files/styles/768x430/public/2019-10/installsportive-footsynthetique-2-web_0.jpg?itok=3nnwAjrd',	3000),
(3,	'Salle 15',	'https://www.tresboeuf.fr/medias/sites/21/2019/10/salle-JBC.jpg',	1200),
(4,	'Centre culturel 1',	'https://previews.123rf.com/images/ismagilov/ismagilov1709/ismagilov170901600/87045223-r%C3%A9ception-de-r%C3%A9ception-en-bois-blanc-et-en-bois-est-dans-un-bureau-avec-des-murs-de-bord-et-des.jpg',	700),
(5,	'Centre culturel 2',	'https://www.stfv.fr/img/location/04-salle-vide.jpg',	1500);

DROP TABLE IF EXISTS `services`;
CREATE TABLE `services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL,
  `prix` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

TRUNCATE `services`;
INSERT INTO `services` (`id`, `nom`, `prix`) VALUES
(1,	'Option de mise en place',	20),
(2,	'Option de nettoyage',	20);

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL,
  `pnom` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `mail` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

TRUNCATE `users`;
INSERT INTO `users` (`id`, `nom`, `pnom`, `phone`, `mail`) VALUES
(1,	'',	'',	'',	''),
(2,	'',	'',	'',	''),
(3,	'Vienne',	'Alexis',	'0692',	'alexis.vienne@gmail.com'),
(4,	'Vienne',	'Alexis',	'0692',	'alexis.vienne@gmail.com'),
(5,	'',	'',	'',	''),
(6,	'',	'',	'',	''),
(7,	'',	'',	'',	''),
(8,	'',	'',	'',	''),
(9,	'',	'',	'',	''),
(10,	'',	'',	'',	''),
(11,	'Vienne',	'Alexis',	'0692',	'alexis.vienne@gmail.com'),
(12,	'Vienne',	'Alexis',	'0692',	'alexis.vienne@gmail.com'),
(13,	'',	'',	'',	''),
(14,	'',	'',	'',	''),
(15,	'',	'',	'',	''),
(16,	'Vienne',	'Alexis',	'0692',	'alexis.vienne@gmail.com'),
(17,	'Vienne',	'Alexis',	'0692',	'alexis.vienne@gmail.com'),
(18,	'',	'',	'',	''),
(19,	'',	'',	'',	''),
(20,	'Vienne',	'Alexis',	'0692',	'alexis.vienne@gmail.com'),
(21,	'',	'',	'',	''),
(22,	'',	'',	'',	''),
(23,	'',	'',	'',	''),
(24,	'',	'',	'',	''),
(25,	'',	'',	'',	''),
(26,	'',	'',	'',	''),
(27,	'',	'',	'',	''),
(28,	'',	'',	'',	''),
(29,	'',	'',	'',	''),
(30,	'',	'',	'',	''),
(31,	'',	'',	'',	''),
(32,	'',	'',	'',	''),
(33,	'',	'',	'',	''),
(34,	'',	'',	'',	''),
(35,	'',	'',	'',	''),
(36,	'',	'',	'',	''),
(37,	'',	'',	'',	''),
(38,	'',	'',	'',	''),
(39,	'',	'',	'',	''),
(40,	'',	'',	'',	''),
(41,	'',	'',	'',	''),
(42,	'',	'',	'',	''),
(43,	'',	'',	'',	''),
(44,	'',	'',	'',	''),
(45,	'',	'',	'',	''),
(46,	'',	'',	'',	''),
(47,	'',	'',	'',	'');

-- 2024-04-16 12:40:00
